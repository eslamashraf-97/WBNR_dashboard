<template>
	<div class="text-center">
		<img src="../../assets/images/global/noData.png" />
		<p>You don’t have any transactions yet.</p>
	</div>
</template>
