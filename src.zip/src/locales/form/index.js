import formEn from './en';
import formAr from './ar';

export { formEn, formAr };
