import authEn from './en';
import authAr from './ar';

export { authEn, authAr };
