import index from './pages/index.vue';

export default [{
    name: 'chat',
    path: '/chat',
    component: index
}]
