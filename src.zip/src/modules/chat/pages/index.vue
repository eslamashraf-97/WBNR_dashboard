<template>
  <div>
<!--    {{ allCollections }}-->
  </div>
</template>
<script setup>
// import useFirebase from '../compasables/useFirebase'
import {onMounted} from "vue";
// const {getAllCollections, allCollections} = useFirebase()

onMounted(()=>{
  // getAllCollections()
})
</script>
