import index from './pages/index.vue';

export default [{
    name: 'governorates',
    path: '/governorates',
    component: index
}]
