import index from './pages/index.vue';

export default [{
    name: 'products',
    path: '/products',
    component: index
}]
