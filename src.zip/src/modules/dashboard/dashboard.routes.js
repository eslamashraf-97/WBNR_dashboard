import index from './pages/index.vue';

export default [{
    name: 'index',
    path: 'index',
    component: index
}]
