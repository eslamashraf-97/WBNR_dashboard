import index from './pages/index.vue';

export default [{
    name: 'returnedOrder',
    path: '/returned-orders',
    component: index
}]
