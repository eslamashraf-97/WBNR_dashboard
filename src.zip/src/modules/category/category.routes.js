import index from './pages/index.vue';

export default [{
    name: 'categories',
    path: '/categories',
    component: index
}]
