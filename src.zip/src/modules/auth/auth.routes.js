import login from './pages/login.vue';

export default [{
    name: 'signIn',
    path: 'sign-in',
    component: login
}]
