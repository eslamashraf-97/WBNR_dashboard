import index from './pages/index.vue';

export default [{
    name: 'walletRequests',
    path: '/wallet-request',
    component: index
}]
