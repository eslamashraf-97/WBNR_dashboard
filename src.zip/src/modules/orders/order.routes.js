import index from './pages/index.vue';

export default [{
    name: 'orders',
    path: '/orders',
    component: index
}]
