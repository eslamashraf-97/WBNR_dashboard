import index from './pages/index.vue';

export default [{
    name: 'customers',
    path: '/customers',
    component: index
}]
