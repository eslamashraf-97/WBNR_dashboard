<template>
  <div class="bg-white fixed w-full z-10 top-0 shadow-nav flex justify-between items-center gap-2 py-2 px-10">
    <div class="flex gap-2 w-100">
      <img
          class="w-auto"
          src="@/assets/images/logo/logo.png"
          alt=""
     />
    </div>
    <div>
      <Button type="button"  @click="toggle" aria-haspopup="true" aria-controls="overlay_menu">
        <img src="@/assets/images/notification.gif" width="40" />
      </Button>
      <Menu ref="menu" id="overlay_menu" class="w-[17rem]" :model="items" :popup="true">
        <template #start>
          <div class="bg-primary-300 px-2 py-2 text-white rounded-b-xl">
              <h6>Notifications</h6>
          </div>
        </template>
        <template #item="{ item, props }">
          <div @click="changeItemStatus(item)" :class="['px-2 py-2 cursor-pointer bg-gray-200 border-b', {'!bg-white' : item.is_read || allSelected.includes(item.id)}]">
            <h5 class="text-lg">{{item.title}}</h5>
            <p>{{item.body}}</p>
            <p class="text-sm text-left">{{item.createdAt.substring(0,10)}}</p>
          </div>
        </template>
      </Menu>
    </div>
    <span @click="$emit('openMobileMenu')" class="lg:hidden">
      <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="20" height="20" viewBox="0 0 48 48">
        <linearGradient id="C9TYDZarys49lHDy~k4THa_eofQ1g5BaAx6_gr1" x1="12.373" x2="34.611" y1="-154.373" y2="-176.611" gradientTransform="matrix(1 0 0 -1 0 -154)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0077d2"></stop><stop offset="1" stop-color="#0b59a2"></stop></linearGradient><path fill="url(#C9TYDZarys49lHDy~k4THa_eofQ1g5BaAx6_gr1)" d="M42,15H6c-1.65,0-3-1.35-3-3v0c0-1.65,1.35-3,3-3h36c1.65,0,3,1.35,3,3v0	C45,13.65,43.65,15,42,15z"></path><linearGradient id="C9TYDZarys49lHDy~k4THb_eofQ1g5BaAx6_gr2" x1="12.373" x2="34.611" y1="-166.373" y2="-188.611" gradientTransform="matrix(1 0 0 -1 0 -154)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0077d2"></stop><stop offset="1" stop-color="#0b59a2"></stop></linearGradient><path fill="url(#C9TYDZarys49lHDy~k4THb_eofQ1g5BaAx6_gr2)" d="M42,27H6c-1.65,0-3-1.35-3-3v0c0-1.65,1.35-3,3-3h36c1.65,0,3,1.35,3,3v0	C45,25.65,43.65,27,42,27z"></path><linearGradient id="C9TYDZarys49lHDy~k4THc_eofQ1g5BaAx6_gr3" x1="12.373" x2="34.611" y1="-178.373" y2="-200.611" gradientTransform="matrix(1 0 0 -1 0 -154)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0077d2"></stop><stop offset="1" stop-color="#0b59a2"></stop></linearGradient><path fill="url(#C9TYDZarys49lHDy~k4THc_eofQ1g5BaAx6_gr3)" d="M42,39H6c-1.65,0-3-1.35-3-3v0c0-1.65,1.35-3,3-3h36c1.65,0,3,1.35,3,3v0	C45,37.65,43.65,39,42,39z"></path>
      </svg>
    </span>
  </div>
</template>
<script setup>
import { ref } from 'vue'
import Menu from "primevue/menu";
import services from "@/services";
import {useRouter} from "vue-router";

const router = useRouter()
const menu = ref();
const items = ref([
]);
const allSelected = ref([])
function getNotification() {
  services.getNotification().then(res => {
    items.value = res.data.data
  })
}
getNotification()
const toggle = (event) => {
  menu.value.toggle(event);
};
function changeItemStatus(item) {
  services.changeItemStatus(item.id)
  allSelected.value.push(item.id)
  if(item.type == 'order') {
    router.push({name:'orders', query: {id:item.id }})
  }
}
</script>
<style>
.p-menu-list {
  max-height: 600px !important;
  overflow: auto;
}
</style>
